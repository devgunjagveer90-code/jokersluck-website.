# Jokersluck Brand Guidelines

## Brand Overview
Jokersluck provides high-quality design and development services (flyers, logos, websites) for small businesses and startups. The brand identity balances professional reliability with a clever, modern edge.

## Logo
- **Primary Logo**: `logo_main.png`
  - A minimalist 'J' integrated with a stylized jester hat. 
  - Represents the "Wild Card" advantage and professional excellence.
- **Secondary Logo**: `logo_secondary.png`
  - A premium geometric diamond with a gold crown.
  - Used for high-end corporate clients.

## Color Palette
- **Midnight Navy**: `#001F3F`
  - Primary color. Evokes trust, stability, and professionalism.
- **Emerald Luck**: `#2ECC71`
  - Accent color. Represents growth, luck, and vibrancy.
- **Pure White**: `#FFFFFF`
  - Background/Secondary color. For clarity and modern feel.
- **Slate Gray**: `#7F8C8D`
  - Neutral color. Used for subtle text and borders.

## Typography
- **Headings**: Montserrat (Bold)
  - A modern, geometric sans-serif that feels contemporary and clean.
- **Body Text**: Open Sans (Regular)
  - Highly legible and professional for all platforms.

## Brand Kit
See `brand_kit.png` for a visual summary of these guidelines.
